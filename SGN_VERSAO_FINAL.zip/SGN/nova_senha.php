<?php
session_start();
include 'config.php'; // Certifique-se de criar um arquivo separado para conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $new_password = md5($_POST['new_password']); // A senha no banco está criptografada com MD5

    // Verifica se o e-mail existe no banco de dados
    $stmt = $conn->prepare("SELECT * FROM usuario_setor_professor_administrador WHERE Email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Atualiza a senha
        $stmt = $conn->prepare("UPDATE usuario_setor_professor_administrador SET Senha = ? WHERE Email = ?");
        $stmt->bind_param("ss", $new_password, $email);
        if ($stmt->execute()) {
            $msg = "Senha alterada com sucesso!";
            $msg_type = "success";
        } else {
            $msg = "Erro ao atualizar a senha.";
            $msg_type = "danger";
        }
    } else {
        $msg = "E-mail não encontrado.";
        $msg_type = "warning";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>Alterar Senha</title>
</head>
<body class="d-flex align-items-center justify-content-center min-vh-100 bg-light">
    <main class="w-100 mx-auto" style="max-width: 400px;">
        <form method="POST" class="p-4 bg-white shadow rounded">
            <div class="text-center mb-4">
                <img src="logo.png" class="mb-3" style="height: 110px;" alt="Logo">
                <h1 style="color: darkblue;" class="h3">Alterar Senha</h1>
            </div>
            <?php if (isset($msg)): ?>
                <div class="alert alert-<?= htmlspecialchars($msg_type) ?> text-center" role="alert">
                    <?= htmlspecialchars($msg) ?>
                </div>
            <?php endif; ?>
            <div class="form-floating mb-3">
                <input style="border-color: darkblue;" name="email" type="email" class="form-control" id="floatingEmail" placeholder="name@example.com" required>
                <label style="color: darkblue;" for="floatingEmail">Endereço de e-mail</label>
            </div>
            <div class="form-floating mb-3">
                <input style="border-color: darkblue;" name="new_password" type="password" class="form-control" id="floatingPassword" placeholder="Nova Senha" required>
                <label style="color: darkblue;" for="floatingPassword">Nova Senha</label>
            </div>
            <button style="background-color: darkblue; color: white;" class="w-100 btn btn-lg btn-primary" type="submit">Alterar Senha</button>
            <div class="mt-3 text-end">
                <a href="f_login.php" class="text-decoration-none text-primary">Voltar para Login</a>
            </div>
        </form>
    </main>
</body>
</html>
