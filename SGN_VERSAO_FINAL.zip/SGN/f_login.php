<!DOCTYPE html>
<html lang="pt-br" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="stylelogin.css" rel="stylesheet">
    <title>Página de Login</title>
</head>
<body class="d-flex align-items-center justify-content-center min-vh-100 bg-light">
    <main class="w-100 mx-auto" style="max-width: 400px;">
        <form action="login.php" method="post" class="p-4 bg-white shadow rounded">
            <div class="text-center mb-4">
                <img src="logo.png" class="mb-3" style="height: 110px;" alt="Logo">
                <h1 style="color: darkblue;" class="h3">Login</h1>
            </div>
            <div class="form-floating mb-3">
                <input style="border-color: darkblue;" name="email" type="email" class="form-control" id="floatingInput" placeholder="name@example.com" required>
                <label style="color: darkblue;" for="floatingInput">Endereço de email</label>
            </div>
            <div class="form-floating mb-3">
                <input style="border-color: darkblue;" name="senha" type="password" class="form-control" id="floatingPassword" placeholder="Password" required>
                <label style="color: darkblue;" for="floatingPassword">Senha</label>
            </div>
            <div class="mb-3 text-end">
                <a href="recuperar_senha.php" class="text-decoration-none text-primary">Esqueceu a senha?</a>
            </div>
            <button style="background-color: darkblue; color: white;" class="w-100 btn btn-lg btn-primary" type="submit">Entrar</button>
        </form>
    </main>
</body>
</html>
