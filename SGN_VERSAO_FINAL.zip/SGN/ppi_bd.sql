-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Tempo de geração: 05/02/2025 às 23:11
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `ppi`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `aluno`
--

CREATE TABLE `aluno` (
  `CPF` varchar(50) NOT NULL,
  `Acompanhamento` int(11) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Nome` varchar(50) DEFAULT NULL,
  `Aux_permanencia` int(11) DEFAULT NULL,
  `Cidade` varchar(50) DEFAULT NULL,
  `Genero` varchar(50) DEFAULT NULL,
  `Reprovacoes` int(11) DEFAULT NULL,
  `Apoio_psic` int(11) DEFAULT NULL,
  `Cotista` int(11) DEFAULT NULL,
  `Data_nasc` date DEFAULT NULL,
  `UF` varchar(50) DEFAULT NULL,
  `Estagio` int(11) DEFAULT NULL,
  `Interno` int(11) DEFAULT NULL,
  `Matricula` int(11) DEFAULT NULL,
  `Acomp_saude` int(11) DEFAULT NULL,
  `Proj_pesq` int(11) DEFAULT NULL,
  `Proj_ext` int(11) DEFAULT NULL,
  `Proj_ens` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `aluno`
--

INSERT INTO `aluno` (`CPF`, `Acompanhamento`, `Email`, `Nome`, `Aux_permanencia`, `Cidade`, `Genero`, `Reprovacoes`, `Apoio_psic`, `Cotista`, `Data_nasc`, `UF`, `Estagio`, `Interno`, `Matricula`, `Acomp_saude`, `Proj_pesq`, `Proj_ext`, `Proj_ens`) VALUES
('03674908649', 0, 'vitor.2023303556@aluno.iffar.edu.br', 'Vitor', 0, 'Frederico Westphalen', 'Masculino', 0, 0, 1, '2007-10-04', 'RS', 0, 0, 2023303556, 0, 1, 0, 0),
('03861278082', 0, 'diego.2024303456', 'Diego Armando', 1, 'Frederico Westphalen', 'Masculino', 0, 0, 1, '2008-12-04', 'RS', 0, 1, 2024303456, 0, 1, 0, 0),
('04678908687', 1, 'pedro.2024280887@aluno.iffar.edu.br', 'Pedro', 1, 'Palmitinho', 'Masculino', 0, 1, 1, '2008-10-08', 'RS', 1, 1, 2024280887, 1, 1, 1, 1),
('04698998657', 0, 'antonio.2023303457@aluno.iffar.edu.br', 'Antônio de Souza Pinheiro', 0, 'Frederico Westphalen', 'Masculino', 0, 0, 0, '2007-11-22', 'RS', 0, 0, 2023303457, 0, 0, 0, 0),
('04861168082', 0, 'jean.2022303457@aluno.iffar.edu.br', 'Jean', 0, 'Frederico Westphalen', 'Masculino', 0, 0, 0, '2006-06-26', 'RS', 0, 0, 2022303457, 0, 0, 0, 0),
('04881166088', 0, 'carlos.2024313455@aluno.iffar.edu.br', 'Carlos', 0, 'Frederico Westphalen', 'Masculino', 0, 0, 0, '2008-09-25', 'RS', 1, 0, 2024313455, 1, 0, 1, 0),
('67414994081', 0, 'jaco.2022303367@aluno.iffar.edu.br', 'Jacó', 0, 'Palmitinho', 'Masculino', 0, 0, 0, '2024-11-24', 'RS', 0, 0, 2022303367, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `curso`
--

CREATE TABLE `curso` (
  `ID` int(11) NOT NULL,
  `Nome` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `curso`
--

INSERT INTO `curso` (`ID`, `Nome`) VALUES
(27, 'Informática'),
(28, 'Administração'),
(29, 'Agropecuária');

-- --------------------------------------------------------

--
-- Estrutura para tabela `disciplina`
--

CREATE TABLE `disciplina` (
  `ID` int(11) NOT NULL,
  `Nome` varchar(50) DEFAULT NULL,
  `idTurma` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `disciplina`
--

INSERT INTO `disciplina` (`ID`, `Nome`, `idTurma`) VALUES
(49, 'Português', 46),
(50, 'Matemática', 48),
(51, 'Matemática', 47),
(52, 'Inglês', 48),
(53, 'Matematica', 46),
(54, 'Inglês', 46),
(55, 'Matematica', 49),
(56, 'Historia', 49),
(57, 'Português', 49),
(58, 'Inglês', 47);

-- --------------------------------------------------------

--
-- Estrutura para tabela `disciplina_aluno`
--

CREATE TABLE `disciplina_aluno` (
  `PPI` float DEFAULT NULL,
  `MC` float DEFAULT NULL,
  `AIA` float DEFAULT NULL,
  `Observacoes` varchar(50) DEFAULT NULL,
  `AIS` float DEFAULT NULL,
  `Faltas` int(11) DEFAULT NULL,
  `Nota1` float DEFAULT NULL,
  `Nota2` float DEFAULT NULL,
  `CPF` varchar(14) NOT NULL,
  `ID` int(11) NOT NULL,
  `parcial1` int(11) DEFAULT NULL,
  `parcial2` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `disciplina_aluno`
--

INSERT INTO `disciplina_aluno` (`PPI`, `MC`, `AIA`, `Observacoes`, `AIS`, `Faltas`, `Nota1`, `Nota2`, `CPF`, `ID`, `parcial1`, `parcial2`) VALUES
(8, 8, 0, '', 9, 0, 6, 8, '03674908649', 49, 0, 7),
(8, 8, 0, '', 9, 0, 8, 10, '03674908649', 53, 0, 7),
(8, 8, 0, 'Fluente', 9, 0, 8, 9, '03674908649', 54, 0, 7),
(0, 0, 0, '', 0, 0, 0, 0, '03861278082', 55, 0, 0),
(0, 0, 0, '', 0, 0, 0, 0, '03861278082', 56, 0, 0),
(0, 0, 0, '', 0, 0, 0, 0, '03861278082', 57, 0, 0),
(0, 0, 0, 'Obs teste', 0, 0, 9, 9, '04678908687', 49, 8, 9),
(0, 0, 0, '', 0, 0, 10, 7, '04678908687', 53, 6, 9),
(0, 0, 0, 'Mais um texto', 0, 0, 0, 0, '04678908687', 54, 0, 3),
(0, 0, 0, '', 0, 0, 0, 0, '04698998657', 51, 0, 0),
(0, 0, 0, '', 0, 0, 0, 0, '04698998657', 58, 0, 0),
(0, 0, 0, '', 0, 0, 0, 0, '04861168082', 51, 0, 0),
(0, 0, 0, '', 0, 0, 0, 0, '04861168082', 58, 0, 0),
(0, 0, 0, '', 0, 0, 0, 0, '04881166088', 55, 0, 0),
(0, 0, 0, '', 0, 0, 0, 0, '04881166088', 56, 0, 0),
(0, 0, 0, '', 0, 0, 0, 0, '04881166088', 57, 0, 0),
(0, 0, 0, 'Muito bom', 7, 3, 10, 2, '67414994081', 49, 7, 7),
(0, 0, 0, '', 0, 0, 0, 0, '67414994081', 53, 8, 0),
(0, 0, 0, 'assdcee', 0, 0, 0, 0, '67414994081', 54, 0, 4);

-- --------------------------------------------------------

--
-- Estrutura para tabela `leciona`
--

CREATE TABLE `leciona` (
  `ID` int(11) NOT NULL,
  `idProfessor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `leciona`
--

INSERT INTO `leciona` (`ID`, `idProfessor`) VALUES
(50, 20),
(52, 20),
(53, 20),
(49, 21),
(51, 21),
(54, 21),
(56, 21),
(57, 24),
(55, 25),
(58, 25);

-- --------------------------------------------------------

--
-- Estrutura para tabela `turma`
--

CREATE TABLE `turma` (
  `Data_entrega` date DEFAULT NULL,
  `Nome` varchar(50) DEFAULT NULL,
  `ID` int(11) NOT NULL,
  `idCurso` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `turma`
--

INSERT INTO `turma` (`Data_entrega`, `Nome`, `ID`, `idCurso`) VALUES
('2025-02-05', '24', 46, 27),
('2025-03-13', '34', 47, 27),
('2025-02-07', '35', 48, 28),
('2025-02-08', '14', 49, 27),
('2025-02-13', '13', 50, 29);

-- --------------------------------------------------------

--
-- Estrutura para tabela `turma_aluno`
--

CREATE TABLE `turma_aluno` (
  `ID` int(11) NOT NULL,
  `CPF` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `turma_aluno`
--

INSERT INTO `turma_aluno` (`ID`, `CPF`) VALUES
(46, '03674908649'),
(46, '04678908687'),
(46, '67414994081'),
(47, '04698998657'),
(47, '04861168082'),
(49, '03861278082'),
(49, '04881166088');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario_setor_professor_administrador`
--

CREATE TABLE `usuario_setor_professor_administrador` (
  `Email` varchar(50) DEFAULT NULL,
  `Senha` varchar(50) DEFAULT NULL,
  `Tipo_usuario` varchar(50) DEFAULT NULL,
  `Nome` varchar(50) DEFAULT NULL,
  `ID` int(11) NOT NULL,
  `Alt_list_prof` int(11) DEFAULT NULL,
  `G_alunos` int(11) DEFAULT NULL,
  `G_emiss` int(11) DEFAULT NULL,
  `G_datas` int(11) DEFAULT NULL,
  `G_orient` int(11) DEFAULT NULL,
  `G_obs` int(11) DEFAULT NULL,
  `G_notas` int(11) DEFAULT NULL,
  `G_faltas` int(11) DEFAULT NULL,
  `MatriculaSiape` varchar(50) DEFAULT NULL,
  `token_recuperacao` varchar(100) DEFAULT NULL,
  `token_expira` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuario_setor_professor_administrador`
--

INSERT INTO `usuario_setor_professor_administrador` (`Email`, `Senha`, `Tipo_usuario`, `Nome`, `ID`, `Alt_list_prof`, `G_alunos`, `G_emiss`, `G_datas`, `G_orient`, `G_obs`, `G_notas`, `G_faltas`, `MatriculaSiape`, `token_recuperacao`, `token_expira`) VALUES
('Jean@gmail.com', 'e8d95a51f3af4a3b134bf6bb680a213a', 'admin', 'Jean', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('cae@gmail.com', 'e8d95a51f3af4a3b134bf6bb680a213a', 'setor', 'CAE', 10, 0, 1, 1, 1, 1, 1, 0, 0, NULL, NULL, NULL),
('CAI@gmail.com', 'e8d95a51f3af4a3b134bf6bb680a213a', 'setor', 'CAI', 11, 0, 1, 0, 0, 1, 1, 0, 0, NULL, NULL, NULL),
('jean.2022303457@aluno.iffar.edu.br', 'e8d95a51f3af4a3b134bf6bb680a213a', 'prof', 'Jean', 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '01023', '2543d479b9e919f007a57b0c6d8c9133320473cac7cc768fbd7cab25ffded3adc27caea53308ac5594b3cef44a0346463138', '2025-02-05 19:44:50'),
('jaco@gmail.com', 'e8d95a51f3af4a3b134bf6bb680a213a', 'prof', 'Jacó', 21, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3454645464', NULL, NULL),
('teste@gmail.com', 'e8d95a51f3af4a3b134bf6bb680a213a', 'setor', 'teste', 22, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL),
('sigaa@gmail.com', 'e8d95a51f3af4a3b134bf6bb680a213a', 'setor', 'Sigaa', 23, 0, 0, 1, 0, NULL, 0, 0, 0, NULL, NULL, NULL),
('lucas@gmail.com', 'e8d95a51f3af4a3b134bf6bb680a213a', 'prof', 'Lucas', 24, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '123456778', NULL, NULL),
('Cristian@gmail.com', '202cb962ac59075b964b07152d234b70', 'prof', 'Cristian', 25, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '908654686', NULL, NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`CPF`);

--
-- Índices de tabela `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`ID`);

--
-- Índices de tabela `disciplina`
--
ALTER TABLE `disciplina`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `idTurma` (`idTurma`);

--
-- Índices de tabela `disciplina_aluno`
--
ALTER TABLE `disciplina_aluno`
  ADD PRIMARY KEY (`CPF`,`ID`);

--
-- Índices de tabela `leciona`
--
ALTER TABLE `leciona`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `idProfessor` (`idProfessor`);

--
-- Índices de tabela `turma`
--
ALTER TABLE `turma`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `idCurso` (`idCurso`);

--
-- Índices de tabela `turma_aluno`
--
ALTER TABLE `turma_aluno`
  ADD PRIMARY KEY (`ID`,`CPF`);

--
-- Índices de tabela `usuario_setor_professor_administrador`
--
ALTER TABLE `usuario_setor_professor_administrador`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `curso`
--
ALTER TABLE `curso`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de tabela `disciplina`
--
ALTER TABLE `disciplina`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT de tabela `turma`
--
ALTER TABLE `turma`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT de tabela `usuario_setor_professor_administrador`
--
ALTER TABLE `usuario_setor_professor_administrador`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `disciplina`
--
ALTER TABLE `disciplina`
  ADD CONSTRAINT `disciplina_ibfk_1` FOREIGN KEY (`idTurma`) REFERENCES `turma` (`ID`);

--
-- Restrições para tabelas `leciona`
--
ALTER TABLE `leciona`
  ADD CONSTRAINT `leciona_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `disciplina` (`ID`),
  ADD CONSTRAINT `leciona_ibfk_2` FOREIGN KEY (`idProfessor`) REFERENCES `usuario_setor_professor_administrador` (`ID`);

--
-- Restrições para tabelas `turma`
--
ALTER TABLE `turma`
  ADD CONSTRAINT `turma_ibfk_1` FOREIGN KEY (`idCurso`) REFERENCES `curso` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
