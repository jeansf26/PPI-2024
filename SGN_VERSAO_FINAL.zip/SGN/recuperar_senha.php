<?php
session_start();
include 'config.php'; // Arquivo de conexão com o banco

// Inclui as classes do PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PhpMailer/src/Exception.php';
require 'PhpMailer/src/PHPMailer.php';
require 'PhpMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Verifica se o e-mail existe no banco de dados
    $stmt = $conn->prepare("SELECT * FROM usuario_setor_professor_administrador WHERE Email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {

        date_default_timezone_set('America/Sao_Paulo');

        // Gera um token único
        $token = bin2hex(random_bytes(50));

        // Define a validade do token (1 hora)
        $expira_em = date("Y-m-d H:i:s", strtotime("+1 hour"));

        // Salva o token no banco
        $stmt = $conn->prepare("UPDATE usuario_setor_professor_administrador SET token_recuperacao = ?, token_expira = ? WHERE Email = ?");
        $stmt->bind_param("sss", $token, $expira_em, $email);
        $stmt->execute();

        $mail = new PHPMailer(true);

        try {
            // Configuração do servidor SMTP (Gmail)
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'ppi2025t34@gmail.com'; // Coloque seu e-mail
            $mail->Password = 'jdep jkvu iqex miga'; // Coloque a senha do e-mail
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Configuração do e-mail
            $mail->setFrom('ppi2025t34@gmail.com', 'SGN');
            $mail->addAddress($email); // O e-mail do usuário que solicitou a recuperação
            $mail->isHTML(true);
            $mail->Subject = 'Recuperacao de Senha';
            $mail->Body = "Clique no link para redefinir sua senha: <a href='http://localhost/SGN/nova_senha.php?token=$token'>Redefinir Senha</a>";

            $mail->send();
            $msg = "E-mail enviado com sucesso!";
        } catch (Exception $e) {
            $msg = "Erro ao enviar e-mail: {$mail->ErrorInfo}";
        }
    } else {
        $msg = "E-mail não encontrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>Recuperar Senha</title>
</head>
<body class="d-flex align-items-center justify-content-center min-vh-100 bg-light">
    <main class="w-100 mx-auto" style="max-width: 400px;">
        <form method="POST" class="p-4 bg-white shadow rounded">
            <div class="text-center mb-4">
                <img src="logo.png" class="mb-3" style="height: 110px;" alt="Logo">
                <h1 style="color: darkblue;" class="h3">Recuperar Senha</h1>
            </div>
            <?php if (isset($msg)): ?>
                <div class="alert alert-info text-center" role="alert"><?= htmlspecialchars($msg) ?></div>
            <?php endif; ?>
            <div class="form-floating mb-3">
                <input style="border-color: darkblue;" name="email" type="email" class="form-control" id="floatingInput" placeholder="name@example.com" required>
                <label style="color: darkblue;" for="floatingInput">Endereço de e-mail</label>
            </div>
            <button style="background-color: darkblue; color: white;" class="w-100 btn btn-lg btn-primary" type="submit">Enviar</button>
            <div class="mt-3 text-end">
                <a href="f_login.php" class="text-decoration-none text-primary">Voltar para Login</a>
            </div>
        </form>
    </main>
</body>
</html>
