<?php
$servername = "127.0.0.1:3307";
$database = "ppi";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password, $database);
?>