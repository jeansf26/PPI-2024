<!--Checa se o usuário está logado, evitando alterações por invasores-->
<?php
    session_start();
    if (!isset($_SESSION["email"])) {
        header("Location: ../f_login.php");
        exit(); // Adiciona um exit após o header redirecionar para garantir que o script pare de executar
    }

include '../config.php';


// Conexão com o banco de dados
$conn = new mysqli($servername, $username, $password, $database);

$id = $_GET['ID'];

// Consulta para obter os CPFs dos alunos na turma
$sql_at = "SELECT CPF FROM turma_aluno WHERE ID = $id";
$result_at = $conn->query($sql_at);

$cpf_list = [];
if ($result_at->num_rows > 0) {
    while ($row = $result_at->fetch_assoc()) {
        $cpf_list[] = $row['CPF'];
    }
}

// Verifica se há CPFs na lista antes de executar a próxima consulta
if (!empty($cpf_list)) {
    // Constrói uma string com os CPFs separados por vírgula para usar no SQL
    $cpf_list_string = "'" . implode("','", $cpf_list) . "'";

    // Consulta para obter os dados dos alunos com os CPFs da lista
    $sql = "SELECT * FROM aluno WHERE CPF IN ($cpf_list_string)";
    $result = $conn->query($sql);

} else {
    echo '<div class="carousel-item active">
    <div class="d-flex justify-content-center align-items-center h-100">
    <div class="alert alert-warning">Nenhum dado encontrado.</div>
    </div>
    </div>';
                }

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrossel de Alunos</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">

    <style>
        .carousel-item {
            height: 500px;
        }

        .carousel-item .card {
            height: 90%;
            width: 70%;
            margin: auto;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .carousel-inner {
            padding: 20px 0;
        }

        .carousel-control-prev-icon,
        .carousel-control-next-icon {
            background-color: rgba(0, 0, 0, 0.8);
        }

        .icon-casinha {
            font-size: 3.5rem;
            text-align: left;
            margin-top: 10px;
        }

        .card-content {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .card-left, .card-right {
            width: 48%;
            padding: 10px;
        }

        .card-right {
            background-color: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn-back {
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <button class="btn btn-primary btn-back" onclick="history.back();">Voltar</button>

    <div class="container mt-5">
        <div id="carouselAlunos" class="carousel slide" data-bs-ride="false">
            <div class="carousel-inner">
                <?php
                if ($result->num_rows > 0) {
                    $active = true;
                    while ($row = $result->fetch_assoc()) {

                        $cpf = $row['CPF'];
                        $sql_notas = "SELECT * FROM disciplina_aluno WHERE CPF = $cpf";
                        $result_notas = $conn->query($sql_notas);
                        $row_notas = $result_notas->fetch_assoc();

                        ?>
                        <div class="carousel-item <?php echo $active ? 'active' : ''; ?>">
                            <div class="d-flex justify-content-center align-items-center h-100">
                                <div class="card shadow-lg p-4">
                                    <div class="card-body">
                                        <div class="card-content">
                                            <!-- Coluna da esquerda: Dados principais -->
                                            <div class="card-left">
                                                <h3 class="card-title text-primary"><?php echo htmlspecialchars($row['Nome']); ?></h3>
                                                <p class="card-text mt-3">
                                                    <strong>Matrícula:</strong> <?php echo htmlspecialchars($row['Matricula']); ?><br>
                                                    <strong>Gênero:</strong> <?php echo htmlspecialchars($row['Genero']); ?><br>
                                                    <strong>Cidade:</strong> <?php echo htmlspecialchars($row['Cidade']); ?><br>
                                                    <strong>Reprovações:</strong> <?php echo htmlspecialchars($row['Reprovacoes']); ?><br>
                                                    <strong>Apoio Psicológico:</strong> <?php echo $row['Apoio_psic'] ? 'Sim' : 'Não'; ?><br>
                                                    <strong>Acompanhamento de saúde:</strong> <?php echo $row['Acomp_saude'] ? 'Sim' : 'Não'; ?><br>
                                                    <strong>Auxílio Permanência:</strong> <?php echo $row['Aux_permanencia'] ? 'Sim' : 'Não'; ?><br>
                                                    <?php if ($row['Proj_pesq'] == 1) { ?>
                                                        <strong>Participa de Projeto de pesquisa</strong><br><?php
                                                    } ?>
                                                    <?php if ($row['Proj_ext'] == 1) { ?>
                                                        <strong>Participa de Projeto de extensão</strong><br><?php
                                                    } ?>
                                                    <?php if ($row['Proj_ens'] == 1) { ?>
                                                        <strong>Participa de Projeto de ensino</strong><br><?php
                                                    } ?>
                                                </p>
                                            </div>

                                            <!-- Coluna da direita: Notas -->
                                            <div class="card-right">
                                                <h4 class="text-secondary">Notas</h4>
                                                <p class="card-text">
                                                    <strong>Nota da AIS:</strong> <?php echo htmlspecialchars($row_notas['AIS'] ?? 'N/A'); ?><br>
                                                    <strong>Nota MC:</strong> <?php echo htmlspecialchars($row_notas['MC'] ?? 'N/A'); ?><br>
                                                    <strong>Nota PPI:</strong> <?php echo htmlspecialchars($row_notas['PPI'] ?? 'N/A'); ?><br>
                                                </p>
                                            </div>
                                        </div>

                                        <!-- Ícone da casinha no rodapé -->
                                        <div class="icon-casinha">
                                            <?php if ($row['Interno']): ?>
                                                <i class="bi bi-house-fill"></i>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                        $active = false;
                    }
                } 
                ?>
            </div>

            <button class="carousel-control-prev" type="button" data-bs-target="#carouselAlunos" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Anterior</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselAlunos" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Próximo</span>
            </button>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
