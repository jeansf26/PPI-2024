<?php
// Checa se o usuário está logado, evitando alterações por invasores
session_start();
if (!isset($_SESSION["email"])) {
    header("Location: f_login.php");
    exit(); // Adiciona um exit após o header redirecionar para garantir que o script pare de executar
}

include "../config.php";

$id = $_GET['ID'];

$emaillogado = $_SESSION['email'];

$sqlx = "SELECT * FROM usuario_setor_professor_administrador WHERE email='$emaillogado'";
$resultx = $conn->query($sqlx);
$rowsx = $resultx->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="../style.css" rel="stylesheet">
    <title>Geração de Boletins</title>
</head>
<body>
    <!-- Barra lateral -->
    <div class="sidebar">
        <ul>
            <li class="logo">
                <a href="#">
                    <span class="icone">
                        <div class="imgCaixa align-items-center">
                            <img style="width: 50px;" src="../logo.png" alt="...">
                        </div>
                    </span>
                    <span class="titulo">SGN</span>
                </a>
            </li>
            <li>
                <a href="../index.php">
                    <span class="icone bi bi-house"></span>
                    <span class="titulo">Início</span>
                </a>
            </li>
            <li>
                <a href="../CTD/pag_curso.php">
                    <span class="icone bi bi-collection"></span>
                    <span class="titulo">Cursos</span>
                </a>
            </li>
            <li>
                <a href="../pag_prof.php">
                    <span class="icone bi bi-person-circle"></span>
                    <span class="titulo">Professores</span>
                </a>
            </li>
            <li>
                <a href="../pag_aluno.php">
                    <span class="icone bi bi-globe"></span>
                    <span class="titulo">Alunos</span>
                </a>
            </li>
            <li>
                <a href="../pag_set.php">
                    <span class="icone bi bi-calendar-week"></span>
                    <span class="titulo">Setores</span>
                </a>
            </li>
            <li>
                <a href="../confirm_logout.php">
                    <span class="icone bi bi-box-arrow-left"></span>
                    <span class="titulo">Sair</span>
                </a>
            </li>
        </ul>
    </div>

    <h2 style="margin-left: 220px !important;">Seleção de Boletim:</h2>
    <br>

    <!-- Formulário de seleção de boletim -->
    <div class="container" style="margin-left: 220px !important; font-size: 1.3rem; width: 70%; ">
        <form action="gerar_boletim.php" method="get" target="_blank">
            <div class="mb-3">
                <label for="tipo_boletim" class="form-label">Selecione o Tipo de Boletim</label>
                <select class="form-control py-1 form-select" name="tipo_boletim" id="tipo_boletim" required>
                    <option value="1° Parcial">1° Parcial</option>
                    <option value="1° Semestral">1° Semestral</option>
                    <option value="2° Parcial">2° Parcial</option>
                    <option value="2° Semestral">2° Semestral</option>
                </select>
                <input value="<?php echo $id; ?>" type="hidden" name="ID" id="ID">
            </div>
            <button type="submit" class="btn btn-primary p-1">Gerar Boletim</button>
            <button type="button" onclick="goBack()" class="btn btn-danger p-1">Cancelar</button>
        </form>
    </div>

    <script>
        function goBack() {
            window.history.back();
        }
    </script>
</body>
</html>
