<?php 
session_start();
if (!isset($_SESSION["email"])) {
    header("Location: ../f_login.php");
    exit();
}

include "../config.php";
require('../fpdf/fpdf.php');

// Recupera o ID enviado pelo formulário
$id = $_GET['ID'];
$tipo_boletim = $_GET['tipo_boletim'];
$notax = "";

if ($tipo_boletim == "1° Parcial") {
    $notax = "parcial1";
} elseif ($tipo_boletim == "2° Parcial") {
    $notax = "parcial2";
} elseif ($tipo_boletim == "1° Semestral") {
    $notax = "Nota1";
} elseif ($tipo_boletim == "2° Semestral") {
    $notax = "Nota2";
} else {
    die("Tipo de boletim inválido.");
}

$sql_t = "SELECT * FROM turma WHERE ID = $id";
$result_t = $conn->query($sql_t);
$row_t = $result_t->fetch_assoc();

if (!$row_t) {
    die("Turma não encontrada.");
}

$sql = "SELECT * FROM turma_aluno WHERE ID = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Instância do FPDF
    $pdf = new FPDF();

    while ($row = $result->fetch_assoc()) {
        $CPF = $row["CPF"];

        $sqla = "SELECT * FROM aluno WHERE CPF = '$CPF'";
        $resulta = $conn->query($sqla);

        if ($resulta->num_rows > 0) {
            $aluno = $resulta->fetch_assoc();

            $sql_notas = "SELECT * FROM disciplina_aluno WHERE CPF = '$CPF'";
            $result_notas = $conn->query($sql_notas);

            $pdf->AddPage();
            $pdf->SetFont('Arial', 'B', 16);
            $pdf->Cell(0, 10, utf8_decode('Boletim Escolar ' . '- ' . $tipo_boletim), 0, 1, 'C');

            $pdf->SetFont('Arial', '', 12);
            $pdf->Ln(10);
            $pdf->Cell(50, 10, utf8_decode('Nome:'), 0, 0);
            $pdf->Cell(0, 10, utf8_decode($aluno['Nome']), 0, 1);

            $pdf->Cell(50, 10, utf8_decode('Turma:'), 0, 0);
            $pdf->Cell(0, 10, utf8_decode($row_t['Nome']), 0, 1);

            $pdf->Cell(50, 10, utf8_decode('Matrícula:'), 0, 0);
            $pdf->Cell(0, 10, utf8_decode($aluno['Matricula']), 0, 1);

            $pdf->Ln(10);
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(90, 10, utf8_decode('Disciplina'), 1, 0, 'C');
            $pdf->Cell(40, 10, utf8_decode('Nota'), 1, 0, 'C');
            $pdf->Cell(40, 10, utf8_decode('Faltas'), 1, 1, 'C');

            $pdf->SetFont('Arial', '', 12);
            $observacoes = ""; // Variável para armazenar observações

            if ($result_notas->num_rows > 0) {
                while ($nota = $result_notas->fetch_assoc()) {
                    $ID_d = $nota['ID'];

                    $sql_d = "SELECT * FROM disciplina WHERE ID = '$ID_d'";
                    $result_d = $conn->query($sql_d);
                    $row_d = $result_d->fetch_assoc();

                    $pdf->Cell(90, 10, utf8_decode($row_d['Nome']), 1, 0, 'C');
                    $pdf->Cell(40, 10, utf8_decode(number_format($nota[$notax], 2)), 1, 0, 'C');
                    $pdf->Cell(40, 10, utf8_decode($nota['Faltas']), 1, 1, 'C');

                    // Adiciona observação à variável
                    if ($nota['Observacoes'] != "") {
                        $observacoes .= $nota['Observacoes'] . "\n";
                    }
                }
            } else {
                $pdf->Cell(0, 10, utf8_decode('Nenhuma nota encontrada.'), 1, 1, 'C');
            }

            // Adiciona a área de observações
            $pdf->Ln(10);
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(0, 10, utf8_decode('Observações'), 0, 1, 'L');
            $pdf->SetFont('Arial', '', 12);

            // Imprime as observações com MultiCell
            $pdf->MultiCell(0, 10, utf8_decode($observacoes), 1, 'L');
        }
    }

    $pdf->Output();
} else {
    echo utf8_decode("Nenhum dado encontrado para o ID informado.");
}
?>
