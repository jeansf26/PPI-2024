<?php
session_start();
if (!isset($_SESSION["email"])) {
    header("Location: f_login.php");
    exit();
}

include "config.php";

$emaillogado = $_SESSION['email'];

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sqlx = "SELECT * FROM usuario_setor_professor_administrador WHERE email='$emaillogado'";
$resultx = $conn->query($sqlx);
$rowsx = $resultx->fetch_assoc();

// Captura os filtros
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$turma = isset($_GET['turma']) ? $conn->real_escape_string($_GET['turma']) : '';

// Prepara a consulta SQL inicial
$sql = "SELECT * FROM aluno WHERE Nome LIKE '%$search%'";

// Adiciona o filtro de turma, se necessário
if (!empty($turma)) {
    $cpf_a_query = "SELECT CPF FROM turma_aluno WHERE ID LIKE '%$turma%'";
    $sql = "SELECT * FROM aluno WHERE CPF IN ($cpf_a_query)";
}

// Executa a consulta final
$result = $conn->query($sql);

// Tratamento de erros
if (!$result) {
    die("Erro na consulta SQL: " . $conn->error);
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alunos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <!-- Barra lateral -->

            <div class="sidebar">
                <ul>
                    <li class="logo">
                        <a href="#">
                            <span class="icone">
                                <div class="imgCaixa align-items-center">
                                    <img style="width: 50px;" src="logo.png" alt="...">
                                </div>
                            </span>
                            <span class="titulo">SGN</span>
                        </a>
                    </li>
                    <li>
                        <a href="index.php">
                            <span class="icone bi bi-house"></span>
                            <span class="titulo">Início</span>
                        </a>
                    </li>
                    <li>
                        <a href="CTD/pag_curso.php">
                            <span class="icone bi bi-collection"></span>
                            <span class="titulo">Cursos</span>
                        </a>
                    </li>
                    <li>
                        <a href="pag_prof.php">
                            <span class="icone bi bi-person-circle"></span>
                            <span class="titulo">Professores</span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="icone bi bi-globe"></span>
                            <span class="titulo">Alunos</span>
                        </a>
                    </li>
                    <li>
                        <a href="pag_set.php">
                            <span class="icone bi bi-calendar-week"></span>
                            <span class="titulo">Setores</span>
                        </a>
                    </li>
                    <li>
                        <a href="confirm_logout.php">
                            <span class="icone bi bi-box-arrow-left"></span>
                            <span class="titulo">Sair</span>
                        </a>
                    </li>
                </ul>
            </div>
    <!-- Conteúdo principal -->
    <main role="main" class="col-md-9 ms-sm-auto col-lg-10 px-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Lista de Alunos</h1>
        </div>

        <!-- Botão para adicionar aluno -->
        <?php  
        if ($rowsx['Tipo_usuario'] == 'admin' || $rowsx['G_alunos'] == 1) {
            echo "<div class='d-flex justify-content-center col-1 p-2 border border-dark border-3 border-opacity-75 rounded-5 shadow-lg mb-3 bg-primary'>
                    <a href='aluno_registro.php' class='nav-link'><i class='bi bi-plus-square-fill'></i></a>
                </div>";
        }
        ?>

        <!-- Formulário de pesquisa e filtro -->
        <form method="GET" class="row g-3 mb-4">
            <div class="col-md-5 me-2">
                <input type="text" name="search" class="form-control" placeholder="Pesquisar por nome" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-4 ms-2">
                <select name="turma" class="form-select">
                    <option value="">Todas as turmas</option>
                    <?php
                    $sqlTurmas = "SELECT * FROM turma";
                    $resultTurmas = $conn->query($sqlTurmas);

                    while ($rowTurma = $resultTurmas->fetch_assoc()) {
                        $selected = ($rowTurma['ID'] == $turma) ? 'selected' : '';
                        echo "<option value='" . $rowTurma['ID'] . "' $selected>" . $rowTurma['Nome'] . "</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-2 ms-2">
                <button type="submit" class="btn btn-primary w-100">Filtrar</button>
            </div>
        </form>

        <!-- Lista de alunos -->
        <div>
            <?php
            if ($result->num_rows > 0) {
                echo "<div class='container mt-4'><div class='row justify-content-center'>";

                while ($row = $result->fetch_assoc()) {
                    echo "<div class='col-md-6'>
                            <div class='card mb-3 shadow-lg border-0 me-4 ps-2'>
                                <div class='card-body d-flex align-items-center justify-content-between'>
                                    <div>
                                        <h5 class='card-title fw-bold text-primary'>" . $row['Nome'] . "</h5>
                                        <p class='card-text text-muted mb-0'>CPF: " . $row['CPF'] . "</p>
                                    </div>";
                    
                    if ($rowsx['Tipo_usuario'] == 'admin' || $rowsx['G_alunos'] == 1) {
                        echo "<div class='d-flex'>
                                <a href='edit_aluno.php?CPF=" . $row['CPF'] . "' class='btn btn-warning me-2 shadow-sm'>
                                    <i class='bi bi-pencil-square'></i>
                                </a>
                                <a href='exc_aluno.php?CPF=" . $row['CPF'] . "' class='btn btn-danger shadow-sm'>
                                    <i class='bi bi-trash3'></i>
                                </a>
                            </div>";
                    }

                    echo "    </div>
                            </div>
                        </div>";
                }

                echo "</div></div>";
            } else {
                echo "<div class='alert alert-warning text-center mt-4'>Nenhum aluno encontrado.</div>";
            }
            ?>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
